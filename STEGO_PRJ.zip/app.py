from flask import Flask, request, send_file, jsonify, render_template
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from PIL import Image
from cryptography.fernet import Fernet
import io
import base64
import hashlib
from datetime import datetime, timedelta
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)

# REALTIME CHAT
socketio = SocketIO(app, cors_allowed_origins="*")

# ================= SECURITY SETTINGS =================

failed_attempts = {}
BLOCK_TIME = timedelta(hours=24)
MAX_ATTEMPTS = 3


# ================= ENCRYPTION FUNCTIONS =================

def generate_key(password):
    return base64.urlsafe_b64encode(
        hashlib.sha256(password.encode()).digest()
    )

def encrypt_message(message, password):
    fernet = Fernet(generate_key(password))
    return fernet.encrypt(message.encode()).decode()

def decrypt_message(encrypted_text, password):
    fernet = Fernet(generate_key(password))
    return fernet.decrypt(encrypted_text.encode()).decode()

def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

def binary_to_text(binary_data):
    all_bytes = [binary_data[i:i+8] for i in range(0, len(binary_data), 8)]
    decoded_data = ""
    for byte in all_bytes:
        decoded_data += chr(int(byte, 2))
    return decoded_data


# ================= STEGANOGRAPHY =================

def encode_image(image, secret_data):

    binary_data = text_to_binary(secret_data) + "1111111111111110"
    pixels = image.load()
    width, height = image.size
    data_index = 0

    for y in range(height):
        for x in range(width):

            if data_index >= len(binary_data):
                return image

            r, g, b = pixels[x, y]
            r = (r & ~1) | int(binary_data[data_index])
            pixels[x, y] = (r, g, b)
            data_index += 1

    return image


def decode_image(image):

    pixels = image.load()
    width, height = image.size
    binary_data = ""

    for y in range(height):
        for x in range(width):

            r, g, b = pixels[x, y]
            binary_data += str(r & 1)

            if binary_data.endswith("1111111111111110"):
                binary_data = binary_data[:-16]
                return binary_to_text(binary_data)

    return None


# ================= TEMPLATE ROUTES =================

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register-page")
def register_page():
    return render_template("register.html")

@app.route("/login-page")
def login_page():
    return render_template("login.html")

@app.route("/chat-page")
def chat_page():
    return render_template("chat.html")

@app.route("/encode-page")
def encode_page():
    return render_template("encode.html")

@app.route("/decode-page")
def decode_page():
    return render_template("decode.html")

@app.route("/how-page")
def how_page():
    return render_template("how.html")

@app.route("/security-page")
def security_page():
    return render_template("security.html")


# ================= ENCODE API =================

@app.route("/encode", methods=["POST"])
def encode():

    try:

        image_file = request.files["image"]
        message = request.form["message"]
        password = request.form["password"]

        image = Image.open(image_file).convert("RGB")

        encrypted_text = encrypt_message(message, password)
        encoded_image = encode_image(image, encrypted_text)

        img_io = io.BytesIO()
        encoded_image.save(img_io, "PNG")
        img_io.seek(0)

        return send_file(
            img_io,
            mimetype="image/png",
            as_attachment=True,
            download_name="encoded_image.png"
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 400


# ================= DECODE API =================

@app.route("/decode", methods=["POST"])
def decode():

    user_ip = request.remote_addr

    if user_ip in failed_attempts:
        data = failed_attempts[user_ip]

        if data["blocked_until"]:

            if datetime.now() < data["blocked_until"]:
                return jsonify({
                    "error": "You are blocked for 24 hours."
                }), 403

            else:
                failed_attempts[user_ip] = {"count":0,"blocked_until":None}

    try:

        image_file = request.files["image"]
        password = request.form["password"]

        image = Image.open(image_file).convert("RGB")
        extracted_text = decode_image(image)

        if not extracted_text:
            return jsonify({"error":"No hidden data found"}),400

        decrypted_text = decrypt_message(extracted_text,password)

        failed_attempts[user_ip] = {"count":0,"blocked_until":None}

        return jsonify({"message":decrypted_text})

    except Exception:

        if user_ip not in failed_attempts:
            failed_attempts[user_ip] = {"count":0,"blocked_until":None}

        failed_attempts[user_ip]["count"] += 1

        if failed_attempts[user_ip]["count"] >= MAX_ATTEMPTS:

            failed_attempts[user_ip]["blocked_until"] = datetime.now()+BLOCK_TIME

            return jsonify({
                "error":"Too many attempts. Blocked 24 hours."
            }),403

        remaining = MAX_ATTEMPTS - failed_attempts[user_ip]["count"]

        return jsonify({
            "error":f"Wrong password. {remaining} attempts remaining."
        }),401


# ================= DATABASE =================

def init_db():

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT,
        birth_year TEXT,
        life_hero TEXT,
        email TEXT UNIQUE,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender TEXT,
        receiver TEXT,
        message TEXT,
        type TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()

init_db()


# ================= REGISTER =================

@app.route("/register", methods=["POST"])
def register():

    data = request.json

    full_name = data.get("fullName")
    birth_year = data.get("birthYear")
    life_hero = data.get("lifeHero")
    email = data.get("email")
    password = data.get("password")
    username = data.get("username")

    if not all([full_name,birth_year,life_hero,email,password,username]):
        return jsonify({"error":"All fields required"}),400

    hashed_password = generate_password_hash(password)

    try:

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO users(full_name,birth_year,life_hero,email,username,password)
        VALUES(?,?,?,?,?,?)
        """,(full_name,birth_year,life_hero,email,username,hashed_password))

        conn.commit()
        conn.close()

        return jsonify({"message":"User registered successfully"})

    except sqlite3.IntegrityError:
        return jsonify({"error":"Email or Username already exists"}),400


# ================= LOGIN =================

@app.route("/login", methods=["POST"])
def login():

    data = request.json

    username = data.get("username")
    password = data.get("password")

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("SELECT password FROM users WHERE username=?", (username,))
    user = cursor.fetchone()

    conn.close()

    if not user:
        return jsonify({"error":"Username not registered"}),404

    stored_password = user[0]

    if not check_password_hash(stored_password,password):
        return jsonify({"error":"Incorrect password"}),401

    return jsonify({"message":"Login successful"})


# ================= REALTIME CHAT =================

@socketio.on("send_message")
def handle_message(data):

    sender = data["sender"]
    receiver = data["receiver"]
    message = data["message"]
    msg_type = data["type"]

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    # CHECK RECEIVER
    cursor.execute("SELECT username FROM users WHERE username=?", (receiver,))
    user = cursor.fetchone()

    if not user:
        emit("error_message",{"error":"User is invalid"})
        conn.close()
        return

    cursor.execute("""
    INSERT INTO messages(sender,receiver,message,type)
    VALUES(?,?,?,?)
    """,(sender,receiver,message,msg_type))

    conn.commit()
    conn.close()

    emit("receive_message",{
        "sender":sender,
        "receiver":receiver,
        "message":message
    }, broadcast=True)


# ================= DEBUG =================

@app.route("/view-users")
def view_users():

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("SELECT id,username,email FROM users")
    data = cursor.fetchall()

    conn.close()

    return jsonify(data)

@app.route("/check-user/<username>")
def check_user(username):

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("SELECT username FROM users WHERE username=?", (username,))
    user = cursor.fetchone()

    conn.close()

    if user:
        return jsonify({"exists": True})
    else:
        return jsonify({"exists": False})
# ================= START SERVER =================

if __name__ == "__main__":
    print("🚀 Starting Flask Server...")
    socketio.run(app, host="127.0.0.1", port=5000, debug=True)